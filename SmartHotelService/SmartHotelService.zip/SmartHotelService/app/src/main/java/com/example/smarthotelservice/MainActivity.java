package com.example.smarthotelservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.net.Socket;

public class MainActivity extends AppCompatActivity {
    private Button btn_switch, btn_food, btn_chat, btn_setting;
    private TextView text_temp, text_humi, text_rnum;
    private SocketApplication instance;
    private BroadcastReceiver myreceiver;
    private String BROADCAST_MESSAGE = "com.example.smarthotelservice.start_service";
    private Handler handler;
    private IScoketService pService = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_switch = findViewById(R.id.btn_switch);
        btn_chat = findViewById(R.id.btn_chat);

        instance = SocketApplication.getinstance();

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (pService == null) {
                    pService = SocketApplication.getinstance().getpService();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                SocketApplication.getinstance().Connect();
            }
        }).start();

        btn_switch.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SwitchActivity.class);
                startActivity(intent);
            }
        });
        btn_chat.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChatActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

}
