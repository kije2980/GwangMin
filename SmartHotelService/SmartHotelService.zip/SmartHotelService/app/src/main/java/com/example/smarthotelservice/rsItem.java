package com.example.smarthotelservice;

import android.graphics.drawable.Drawable;

public class rsItem {
    private Drawable images;
    private String id;
    private int price;

    public void setImages(Drawable images) {
        this.images = images;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Drawable getImages() {
        return images;
    }

    public String getId() {
        return id;
    }

    public int getPrice() {
        return price;
    }
}
