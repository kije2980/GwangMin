package com.example.smarthotelservice;

import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {
    private ListView chatlist;
    private Button btn_send, btn_close;
    private EditText chat_edit;
    private ArrayList<String> item;
    private ArrayAdapter<String> frontAdapter;
    private ArrayAdapter<String> userAdapter;
    private TextView user_text, front_text;
    private SocketApplication instance;
    private String msg = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        item = new ArrayList<>();
        frontAdapter = new ArrayAdapter<>(this, R.layout.chat_item, R.id.text_front, item);
        userAdapter = new ArrayAdapter<>(this, R.layout.chat_item, R.id.text_user, item);
        chatlist = findViewById(R.id.chat_list);
        chat_edit = findViewById(R.id.chat_edit);
        btn_send = findViewById(R.id.btn_send);
        btn_close = findViewById(R.id.btn_chat_close);
        instance = SocketApplication.getinstance();
        Intent intent = getIntent();
        msg = intent.getStringExtra("msg");

        if(msg!=null)
        {
            recv_msg(msg);
        }

        btn_send.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = chat_edit.getText().toString();
                if (text.length() != 0) {
                    if(chatlist.getAdapter()!=userAdapter)
                        chatlist.setAdapter(userAdapter);
                    item.add(text);
                    try {
                        instance.Send(text);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                    chat_edit.setText("");
                    userAdapter.notifyDataSetChanged();
                }
            }
        });

        btn_close.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
    public void recv_msg(String msg)
    {
        try {
            if (chatlist.getAdapter() != frontAdapter)
                chatlist.setAdapter(frontAdapter);
            item.add(msg);
            frontAdapter.notifyDataSetChanged();
        }
        catch (Exception e)
        {
            Log.d("ChatA Recv Err : ", e.toString());
        }
    }

}