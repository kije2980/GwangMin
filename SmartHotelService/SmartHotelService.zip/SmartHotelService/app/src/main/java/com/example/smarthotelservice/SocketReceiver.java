package com.example.smarthotelservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SocketReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals("com.example.smarthotelservice.Chat_Receive"))
        {
            Intent intent1 = new Intent("com.example.smarthotelservice.Chat_Send");
            intent1.putExtra("msg", intent.getStringExtra("msg"));
        }
    }
}
