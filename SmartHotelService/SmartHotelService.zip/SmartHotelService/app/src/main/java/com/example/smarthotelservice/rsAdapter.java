package com.example.smarthotelservice;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class rsAdapter extends BaseAdapter {
    private ArrayList<rsItem> rsitem = new ArrayList<>();
    Context context;

    @Override
    public int getCount() {
        return rsitem.size();
    }

    @Override
    public rsItem getItem(int position) {

        return rsitem.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        context = parent.getContext();
        if(convertView == null)
        {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.rs_item, parent, false);

            ImageView images = convertView.findViewById(R.id.images);
            TextView food_id = convertView.findViewById(R.id.food_id);
            TextView food_price = convertView.findViewById(R.id.food_pirce);

            rsItem rsItem = getItem(position);

            images.setImageDrawable(rsItem.getImages());
            food_id.setText(rsItem.getId());
            food_price.setText(rsItem.getPrice());
        }
        return convertView;
    }

    public void addItem(Drawable img, String id, int price){
        rsItem rsitem = new rsItem();

        rsitem.setImages(img);
        rsitem.setId(id);
        rsitem.setPrice(price);
    }
}
