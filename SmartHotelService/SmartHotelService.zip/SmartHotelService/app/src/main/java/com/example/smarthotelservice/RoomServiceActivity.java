package com.example.smarthotelservice;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import io.realm.Realm;

public class RoomServiceActivity extends AppCompatActivity {
    SocketApplication instance;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_service);

        Realm.init(this);
        Realm mRealm = Realm.getDefaultInstance();

        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                FoodVO vo = realm.createObject(FoodVO.class);
                vo.setName("아메리카노");
                vo.setPrice(3000);
                vo.setSize("L");
            }
        });
        instance = SocketApplication.getinstance();
        listView = findViewById(R.id.rsList);

    }

}